function Aldrin() {
  var numAldrin = document.getElementById("Kaktus").value;
  var adaAldrin;
  if (numAldrin < 25) {
    adaAldrin = "Underskrider";
  } else {
    adaAldrin = "&Ouml;verskrider";
  }
  document.getElementById("aldrin").innerHTML = adaAldrin;
}
function Arsenik() {
  var numArsenik = document.getElementById("smultron").value;
  var adaArsenik;
  if (numArsenik < 25) {
    adaArsenik = "Underskrider";
  } else {
    adaArsenik = "&Ouml;verskrider";
  }
  document.getElementById("arsenik").innerHTML = adaArsenik;
}
function Barium() {
  var numBarium = document.getElementById("hallon").value;
  var adaBarium;
  if (numBarium < 25) {
    adaBarium = "Underskrider";
  } else {
    adaBarium = "&Ouml;verskrider";
  }
  document.getElementById("barium").innerHTML = adaBarium;
}
function Bly() {
  var numBly = document.getElementById("godis").value;
  var adaBly;
  if (numBly < 25) {
    adaBly = "Underskrider";
  } else {
    adaBly = "&Ouml;verskrider";
  }
  document.getElementById("bly").innerHTML = adaBly;
}
function Kobolt() {
  var numKobolt = document.getElementById("tre").value;
  var adaKobolt;
  if (numKobolt < 25) {
    adaKobolt = "Underskrider";
  } else {
    adaKobolt = "&Ouml;verskrider";
  }
  document.getElementById("kobolt").innerHTML = adaKobolt;
}
function Koppar() {
  var numKoppar = document.getElementById("fyra").value;
  var adaKoppar;
  if (numKoppar < 25) {
    adaKoppar = "Underskrider";
  } else {
    adaKoppar = "&Ouml;verskrider";
  }
  document.getElementById("koppar").innerHTML = adaKoppar;
}
function Krom() {
  var numKrom = document.getElementById("fem").value;
  var adaKrom;
  if (numKrom < 25) {
    adaKrom = "Underskrider";
  } else {
    adaKrom = "&Ouml;verskrider";
  }
  document.getElementById("krom").innerHTML = adaKrom;
}
function Nickel() {
  var numNickel = document.getElementById("sex").value;
  var adaNickel;
  if (numNickel < 25) {
    adaNickel = "Underskrider";
  } else {
    adaNickel = "&Ouml;verskrider";
  }
  document.getElementById("nickel").innerHTML = adaNickel;
}
function Vanadin() {
  var numVanadin = document.getElementById("sju").value;
  var adaVanadin;
  if (numVanadin < 25) {
    adaVanadin = "Underskrider";
  } else {
    adaVanadin = "&Ouml;verskrider";
  }
  document.getElementById("vanadin").innerHTML = adaVanadin;
}


