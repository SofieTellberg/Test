function calcuLate() {
w = document.getElementById("firstNumber").value;
q = document.getElementById("firstNumber").value;
x = document.getElementById("firstNumber").value;
y = document.getElementById("secondNumber").value;
document.getElementById("numberOne").innerHTML = (x / 2);
document.getElementById("numberTwo").innerHTML = (x / 2) * x / 2;
document.getElementById("numberTree").innerHTML = (x / 2) * x / 2 - y;
document.getElementById("numberFour").innerHTML = (q / 2) * x / 2 * 2;
document.getElementById("numberFive").innerHTML = (((((x / 2)))))*((((x / 2))))-y-(((q / 2))) * ((x/2))*(2);
document.getElementById("lastNumber").innerHTML = Math.sqrt (w / 2 * x / 2 - y - q / 2 * x / 2 * 2);

}