document.getElementById("sviskon").onmouseover = function() {mouseOver()};
document.getElementById("sviskon").onmouseout = function() {mouseOut()};

function mouseOver() {
document.getElementById("sviskon").style.color = "red";
}

function mouseOut() {
document.getElementById("sviskon").style.color = "black";
}

function addRow(){
var amne = document.getElementById('amne').value;
var result = document.getElementById('result').value;
var enhet = document.getElementById('enhet').value;
                  

var table = document.getElementsByTagName('table')[0];
                  

var newRow = table.insertRow(table.rows.length/2+1);
                  
var cel1 = newRow.insertCell(0);
var cel2 = newRow.insertCell(1);
var cel3 = newRow.insertCell(2);
                  
cel1.innerHTML = amne;
cel2.innerHTML = result;
cel3.innerHTML = enhet;
}