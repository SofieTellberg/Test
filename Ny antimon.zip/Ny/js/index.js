/*H�r kommer Antimon*/
function myFunction() {
  var x = document.getElementById("myAntimon");
  var defaultVal = x.defaultValue;
  var currentVal = x.value;
  
  if (defaultVal == currentVal) {
    document.getElementById("Antimon").innerHTML = "Det &ouml;verskrider inte riktv&auml;rdet: "
    + x.defaultValue;
  } else {
    document.getElementById("Antimon").innerHTML = "Gr&auml;nsv&auml;rdet &auml;r " + defaultVal
    + "<br>detta &ouml;verskrider gr&auml;nsv&auml;rdet f&ouml;r antimon ";
  }
}




